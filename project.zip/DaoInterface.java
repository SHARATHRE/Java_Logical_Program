package com.bitlabs.arogyahospital;

public interface DaoInterface {

	   public void patientRegistration(Patient p);
	   public void viewAllPatient(Patient p);
	   public void searchPatientById(int id);
	   public void deletePatientById(int id);
	   public void searchPatientByCity(String city);
	   public void searchPatientByAgeGroup(int start,int end);
	   /*public void medicinesupplier(int id);
	   public void suppliername(String name);
	   public void Dateandtime(String date);
	   public void medicineId(int id);
	   public void medicinename(String name);
	   public void Unitprice(int price);
	   public void Quantity(int quantity);
	   public void ManufactureDate(String mfd);
	   public void ExpiryDate(String date);
	   */
	    
	}