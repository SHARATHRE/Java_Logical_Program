package com.bitlabs.arogyahospital;
import java.util.*;

/**
 * Hello world!
 *
 */
public class App {

    public static void main(String [] args) 
    
    {
    	
    DaoInterface dao=new DaoImpl();
    
    Patient p=new Patient();
    int pag;
    long pan,pn,gn;
    int pid;
    String pnam,pgen,pcity,paddr,gnm,gaddr,dofad;
    
    
   
    Scanner sc=new Scanner(System.in);
    System.out.println("Enter any option to perform mentioned activity :");
    System.out.println(" 1: for patient Registration \n 2: for view All Patient  \n 3: for Search Patient By id \n 4: for Delete Patient By id \n 5: for Search Patient By City \n 6: for search patient age group ");
   
    int n=sc.nextInt();
    if(n<=6)
    {
    if(n==1)
    {   
    	System.out.println("Enter the patient id");
    	pid=sc.nextInt();
    	System.out.println("Enter the patient age");
        pag=sc.nextInt();
        System.out.println("Enter the patient name");
        pnam=sc.next();
        System.out.println("Enter the patient gender");
        pgen=sc.next();
        System.out.println("Enter the patient city");
        pcity=sc.next();
        System.out.println("Enter the patient address");
        paddr=sc.next();
        System.out.println("Enter the Guardian name");
        gnm=sc.next();
        System.out.println("Enter the Guardian address");
        gaddr=sc.next();
        System.out.println("Enter the date of admission");
        dofad=sc.next();
        System.out.println("Enter the patient Aadharr number");
        pan=sc.nextLong();
        System.out.println("Enter the patient phone number");
        pn=sc.nextLong();
        System.out.println("Enter the Gurdian phone number");
        gn=sc.nextLong();
        
    	 p.setId(pid);
         p.setAge(pag);
         p.setName(pnam);
         p.setGender(pgen);
         p.setCity(pcity);
         p.setAddress(paddr);
         p.setGuardian_name(gnm);
         p.setGuardian_address(gaddr);
         p.setDateOfAdmission(dofad);
         p.setAadhar_Card_number(pan);
         p.setContact_number(pn);
         p.setGuardian_contactNumber(gn);
         
    	dao.patientRegistration(p);
    	        
    }
   if(n==2)
   {
    	dao.viewAllPatient(p);
    			
   }
    			
    if(n==3)
    {
    	System.out.println("Enter the patient id");
    	pid=sc.nextInt();
    	dao.searchPatientById(pid);
    }
    			
    if(n==4)
    {
    	System.out.println("Enter the patient id");
    	pid=sc.nextInt();
    	dao.deletePatientById(pid);
    }
    if(n==5)
    {
    	System.out.println("Enter the patient city");
        pcity=sc.next();
    	dao.searchPatientByCity(pcity);
    }
    if(n==6)
    {
    	System.out.print("Enter the age group =  ");
    	int age1=sc.nextInt();
    	System.out.print(" to " );
    	int age2=sc.nextInt();
    	System.out.println("");
    	dao.searchPatientByAgeGroup(age1 , age2);
      
    }
    }
    else
    {
    	System.out.println("Invalid option");
    }
       
}

}